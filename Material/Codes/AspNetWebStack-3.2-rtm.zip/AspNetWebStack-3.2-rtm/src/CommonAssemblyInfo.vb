﻿'Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.

Imports System
Imports System.Reflection
Imports System.Resources
Imports System.Runtime.InteropServices

<Assembly: AssemblyCompany("Microsoft Open Technologies, Inc.")> 
<Assembly: AssemblyCopyright("© Microsoft Open Technologies, Inc. All rights reserved.")> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: ComVisible(False)> 
<Assembly: CLSCompliant(True)> 

<Assembly: NeutralResourcesLanguage("en-US")> 

' ===========================================================================
' DO NOT EDIT OR REMOVE ANYTHING BELOW THIS COMMENT.
' Version numbers are automatically generated based on regular expressions.
' ===========================================================================

<Assembly: AssemblyVersion("5.2.2.0")>   'ASPNETMVC
<Assembly: AssemblyFileVersion("5.2.2.0")>   'ASPNETMVC
<Assembly: AssemblyProduct("Microsoft ASP.NET MVC")> 