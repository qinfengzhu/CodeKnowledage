using System.Reflection;
// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly : AssemblyTitle("Quarz Scheduler .NET")]
[assembly : AssemblyDescription("Quartz Scheduling Framework")]
[assembly : AssemblyCompany("")]
[assembly : AssemblyProduct("Quarz Scheduler .NET")]
[assembly : AssemblyCopyright("Copyright 2007 OpenSymphony")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]

[assembly : AssemblyVersion("0.5.0.*")]

[assembly : AssemblyConfiguration("")]
[assembly : AssemblyDelaySign(false)]
[assembly : AssemblyKeyFile("")]
[assembly : AssemblyKeyName("")]