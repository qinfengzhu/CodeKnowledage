QUARTZ JOB SCHEDULER .NET, release 0.4, March 4 2007
-----------------------------------------------------------------
http://quartznet.sourceforge.net/


1. INTRODUCTION
----------------

This is the README file for Quartz.NET, .NET port of Java Quartz.

Quartz.NET is an opensource project aimed at creating a
free-for-commercial use Job Scheduler, with 'enterprise' features.

Licensed under the Apache License, Version 2.0 (the "License"); you may not 
use this file except in compliance with the License. You may obtain a copy 
of the License at 
 
    http://www.apache.org/licenses/LICENSE-2.0 

Also, to keep the legal people happy:

    This product includes software developed by the
    Apache Software Foundation (http://www.apache.org/)



2. KNOWN ISSUES
---------------

Lots of funtionality still missing.


3. RELEASE INFO
----------------

This release only contains minimal set of functionality that you need to run against RAMJobStore.


