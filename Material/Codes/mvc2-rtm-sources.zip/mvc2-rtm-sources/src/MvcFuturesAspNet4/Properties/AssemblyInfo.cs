﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Microsoft.Web.Mvc.AspNet4")]
[assembly: AssemblyProduct("Microsoft.Web.Mvc.AspNet4")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2009")]
[assembly: ComVisible(false)]
[assembly: Guid("790dfb64-015a-496e-9417-55b1ccf3a95b")]
[assembly: AssemblyVersion("2.0.0.0")]
[assembly: AssemblyFileVersion("2.0.50217.0")]

[assembly: InternalsVisibleTo("Microsoft.Web.Mvc.AspNet4.Test")]