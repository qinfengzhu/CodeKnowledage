﻿namespace Sys.Mvc {
    using System;

    public delegate object Validator(string value, ValidationContext context);

}
