﻿namespace System.Web.Mvc {
    public class ViewTemplateUserControl : ViewTemplateUserControl<object> { }
}
