﻿namespace System.Web.Mvc.Async {

    public interface IAsyncManagerContainer {

        AsyncManager AsyncManager {
            get;
        }

    }
}
