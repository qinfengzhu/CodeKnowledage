﻿namespace System.Web.Mvc.Async {
    using System;

    internal delegate IAsyncResult BeginInvokeDelegate(AsyncCallback callback, object state);
}
