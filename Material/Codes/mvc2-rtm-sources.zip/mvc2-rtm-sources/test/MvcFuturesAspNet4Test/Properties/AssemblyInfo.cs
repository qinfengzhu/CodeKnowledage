﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Web.Mvc.AspNet4.Test")]
[assembly: AssemblyProduct("Microsoft.Web.Mvc.AspNet4.Test")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2009")]
[assembly: ComVisible(false)]
[assembly: Guid("cb255933-36b2-493c-94bd-61a203676724")]
