﻿namespace System.Web.Mvc {

    public class SelectListItem {

        public bool Selected {
            get;
            set;
        }

        public string Text {
            get;
            set;
        }

        public string Value {
            get;
            set;
        }
    }
}
