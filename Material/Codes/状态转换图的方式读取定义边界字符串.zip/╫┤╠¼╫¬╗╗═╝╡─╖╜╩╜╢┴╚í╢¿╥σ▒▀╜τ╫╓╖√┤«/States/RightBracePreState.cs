﻿using System;

namespace SOLib.States
{
    public class RightBracePreState : IState
    {
        public PropertyField Read(PropertyReader context)
        {
            int i = context.Reader.Read();
            if (context.Configurator.StringEndFlag.Equals(i))
            {
                return context.SwitchStringEndState();
            }
            char c = (char)i;
            context.CurrentIndex += 1;
            if (context.Configurator.RightBrace.Equals(c))
            {
                return context.SwitchRightBraceState();
            }
            else
            {
                return context.ReadPropertyField();
            }
        }
    }
}
