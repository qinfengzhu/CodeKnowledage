﻿using System;


namespace SOLib.States
{
    public class LeftBracePreState : IState
    {
        public PropertyField Read(PropertyReader context)
        {
            int i = context.Reader.Read();
            if (context.Configurator.StringEndFlag.Equals(i))
            {
                return context.SwitchStringEndState();
            }
            char c = (char)i;
            context.CurrentIndex += 1;

            if(context.Configurator.LeftBrace.Equals(c))
            {
                return context.SwitchLeftBraceState();
            }
            else
            {
                return context.SwitchEscapeState();
            }
        }
    }
}
