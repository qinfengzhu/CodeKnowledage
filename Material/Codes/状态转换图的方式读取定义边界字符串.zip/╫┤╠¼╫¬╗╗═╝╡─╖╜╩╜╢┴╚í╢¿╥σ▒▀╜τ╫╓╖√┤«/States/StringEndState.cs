﻿using System;

namespace SOLib.States
{
    public class StringEndState : IState
    {
        public PropertyField Read(PropertyReader context)
        {
            int i = context.Reader.Read();
            if (context.Configurator.StringEndFlag.Equals(i))
            {
                return context.SwitchStringEndState();
            }
            char c = (char)i;
            context.CurrentIndex += 1;

            context.PropertyValueBuilder.Clear();
            return context.ReadPropertyField();
        }
    }
}
