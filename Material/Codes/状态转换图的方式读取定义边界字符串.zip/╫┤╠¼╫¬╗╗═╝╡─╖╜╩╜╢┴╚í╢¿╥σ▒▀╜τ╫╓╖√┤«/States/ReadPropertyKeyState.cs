﻿using System;

namespace SOLib.States
{
    public class ReadPropertyKeyState : IState
    {
        public PropertyField Read(PropertyReader context)
        {
            int i = context.Reader.Read();
            int nextvalue = context.Reader.Peek(); 
            if (context.Configurator.StringEndFlag.Equals(i) || context.Configurator.StringEndFlag.Equals(nextvalue))
            {
                return context.SwitchStringEndState();
            }
            char c = (char)i;
            context.CurrentIndex += 1;           
            var nextChar = (char)nextvalue;
            if (context.Configurator.RightBrace.Equals(c) && context.Configurator.RightBrace.Equals(nextChar))
            {
                var propertyFiled = PropertyField.Build(context.PropertyStringIndex, context.CurrentIndex - 1, context.PropertyValueBuilder.ToString());
                context.PropertyValueBuilder.Clear();
                context.SwitchStartEscapeState();             
                return propertyFiled;
            }
            else
            {
                context.PropertyValueBuilder.Append(c);
                return context.ReadPropertyField();
            }
        }
    }
}
