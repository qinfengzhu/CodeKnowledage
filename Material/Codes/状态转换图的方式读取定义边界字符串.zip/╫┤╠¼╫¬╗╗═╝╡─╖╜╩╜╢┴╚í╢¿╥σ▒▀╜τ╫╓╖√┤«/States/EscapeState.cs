﻿using System;

namespace SOLib.States
{
    /// <summary>
    /// EscapeState
    /// </summary>
    public class EscapeState : IState
    {
        public PropertyField Read(PropertyReader context)
        {
            int i = context.Reader.Read();           
            if (context.Configurator.StringEndFlag.Equals(i))
            {
                return context.SwitchStringEndState();
            }
            char c = (char)i;
            context.CurrentIndex += 1;

            if (context.Configurator.LeftBrace.Equals(c))
            {
                return context.SwitchLeftBracePreState();
            }
            return context.ReadPropertyField();
        }
    }
}
