﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SOLib
{
    public static class Template
    {
        public static string Replace(string templateStr,Dictionary<string,object> data)
        {
            List<PropertyField> propertyFields = new List<PropertyField>();         

            using (var textReader = new StringReader(templateStr))
            {
                PropertyReader reader = new PropertyReader(textReader);
                PropertyField filed;

                while ((filed = reader.ReadPropertyField()) != null)
                {
                    propertyFields.Add(PropertyField.Build(filed.PropertyCharStartIndex, filed.PropertyCharEndIndex, filed.PropertyKey));
                }
            }
            StringBuilder templateResult = new StringBuilder();
            int charLastIndex = 0;
            int propertyIndex = 0;
            foreach(var propertyField in propertyFields)
            {
                int startLeftIndex = propertyField.PropertyCharStartIndex - 2;
                int endRightIndex = propertyField.PropertyCharEndIndex + 2;

                templateResult.Append(templateStr.Substring(charLastIndex, startLeftIndex-charLastIndex));
                string key = propertyField.PropertyKey.Trim();
                if (data!=null &&data.ContainsKey(key))
                {
                    templateResult.Append(data[key]);
                }
                charLastIndex = endRightIndex;
                propertyIndex += 1;
            }
            templateResult.Append(templateStr.Substring(charLastIndex, templateStr.Length - charLastIndex));
            return templateResult.ToString();
        }
    }
}
