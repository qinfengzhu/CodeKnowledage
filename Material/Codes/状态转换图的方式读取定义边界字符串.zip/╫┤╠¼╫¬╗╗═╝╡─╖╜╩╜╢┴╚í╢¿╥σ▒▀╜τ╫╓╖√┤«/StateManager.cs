﻿using SOLib.States;
using System;

namespace SOLib
{
    /// <summary>
    /// State Manager
    /// </summary>
    public static class StateManager
    {
        public static IState EscapeState { get; } = new EscapeState();
        public static IState ReadPropertyKeyState { get; } = new ReadPropertyKeyState();
        public static IState LeftBracePreState { get; } = new LeftBracePreState();
        public static IState LeftBraceState { get; } = new LeftBraceState();
        public static IState RightBracePreState { get; } = new RightBracePreState();
        public static IState RightBraceState { get; } = new RightBraceState();
        public static IState StringEndState { get; } = new StringEndState();
    }

    /// <summary>
    /// State Extensions
    /// </summary>
    internal static class StateExtension
    {
        public static void SwitchStartEscapeState(this PropertyReader context)
        {
            context.State = StateManager.EscapeState;
        }
        public static PropertyField SwitchEscapeState(this PropertyReader context)
        {
            context.State = StateManager.EscapeState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchReadPropertyKeyState(this PropertyReader context)
        {
            context.State = StateManager.ReadPropertyKeyState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchLeftBracePreState(this PropertyReader context)
        {
            context.State = StateManager.LeftBracePreState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchLeftBraceState(this PropertyReader context)
        {
            context.State = StateManager.LeftBraceState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchRightBracePreState(this PropertyReader context)
        {
            context.State = StateManager.RightBracePreState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchRightBraceState(this PropertyReader context)
        {
            context.State = StateManager.RightBraceState;
            return context.ReadPropertyField();
        }
        public static PropertyField SwitchStringEndState(this PropertyReader context)
        {
            context.State = StateManager.StringEndState;
            return context.ReadPropertyField();
        }
    }
}
