﻿using System;

namespace SOLib
{
    /// <summary>
    /// Property information
    /// </summary>
    public class PropertyField
    {
        public int PropertyCharStartIndex { get; set; }
        public int PropertyCharEndIndex { get; set; }
        public string PropertyKey { get; set; }
        private PropertyField()
        {
        }

        public static PropertyField Build(int propertyCharStartIndex, int propertyCharEndIndex, string propertyKey)
        {
            var propertyField = new PropertyField();
            propertyField.PropertyCharStartIndex = propertyCharStartIndex;
            propertyField.PropertyCharEndIndex = propertyCharEndIndex;
            propertyField.PropertyKey = propertyKey;
            return propertyField;
        }
    }
}
