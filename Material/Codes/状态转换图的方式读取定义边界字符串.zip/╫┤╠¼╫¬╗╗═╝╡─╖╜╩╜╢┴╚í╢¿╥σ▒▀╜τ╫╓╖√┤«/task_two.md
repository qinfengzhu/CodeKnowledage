﻿### core code (state pattern)

```
/// <summary>
/// State Interface
/// </summary>
public interface IState
{
    PropertyField Read(PropertyReader context);
}

/// <summary>
/// Property information
/// </summary>
public class PropertyField
{
    public int PropertyCharStartIndex { get; set; }
    public int PropertyCharEndIndex { get; set; }
    public string PropertyKey { get; set; }
    private PropertyField()
    {
    }

    public static PropertyField Build(int propertyCharStartIndex, int propertyCharEndIndex, string propertyKey)
    {
        var propertyField = new PropertyField();
        propertyField.PropertyCharStartIndex = propertyCharStartIndex;
        propertyField.PropertyCharEndIndex = propertyCharEndIndex;
        propertyField.PropertyKey = propertyKey;
        return propertyField;
    }
}

/// <summary>
/// Special Character
/// </summary>
public class Configurator
{
    public virtual char LeftBrace => '{';
    public virtual char RightBrace => '}';
    public int StringEndFlag => -1;
}

/// <summary>
/// Property Reader Context
/// </summary>
public class PropertyReader
{
    public TextReader Reader { get; private set; }
    public int PropertyStringIndex { get; set; } = 0;
    public int CurrentIndex { get; set; } = 0;
    public StringBuilder PropertyValueBuilder { get; } = new StringBuilder();
    public Configurator Configurator { get; } = new Configurator();
    public IState State { get; set; } = StateManager.EscapeState;
    public PropertyReader(TextReader reader)
    {
        Reader = reader;
    }

    public PropertyField ReadPropertyField()
    {
        if (State is StringEndState)
        {
            return null;
        }
        return State.Read(this);
    }
}

/// <summary>
/// State Manager
/// </summary>
public static class StateManager
{
    public static IState EscapeState { get; } = new EscapeState();
    public static IState ReadPropertyKeyState { get; } = new ReadPropertyKeyState();
    public static IState LeftBracePreState { get; } = new LeftBracePreState();
    public static IState LeftBraceState { get; } = new LeftBraceState();
    public static IState RightBracePreState { get; } = new RightBracePreState();
    public static IState RightBraceState { get; } = new RightBraceState();
    public static IState StringEndState { get; } = new StringEndState();
}

/// <summary>
/// State Extensions
/// </summary>
internal static class StateExtension
{
    public static void SwitchStartEscapeState(this PropertyReader context)
    {
        context.State = StateManager.EscapeState;
    }
    public static PropertyField SwitchEscapeState(this PropertyReader context)
    {
        context.State = StateManager.EscapeState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchReadPropertyKeyState(this PropertyReader context)
    {
        context.State = StateManager.ReadPropertyKeyState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchLeftBracePreState(this PropertyReader context)
    {
        context.State = StateManager.LeftBracePreState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchLeftBraceState(this PropertyReader context)
    {
        context.State = StateManager.LeftBraceState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchRightBracePreState(this PropertyReader context)
    {
        context.State = StateManager.RightBracePreState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchRightBraceState(this PropertyReader context)
    {
        context.State = StateManager.RightBraceState;
        return context.ReadPropertyField();
    }
    public static PropertyField SwitchStringEndState(this PropertyReader context)
    {
        context.State = StateManager.StringEndState;
        return context.ReadPropertyField();
    }
}
```
* __States__

```
 /// <summary>
/// EscapeState
/// </summary>
public class EscapeState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();           
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;

        if (context.Configurator.LeftBrace.Equals(c))
        {
            return context.SwitchLeftBracePreState();
        }
        return context.ReadPropertyField();
    }
}

 /// <summary>
/// LeftBracePreState
/// </summary>
public class LeftBracePreState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;

        if(context.Configurator.LeftBrace.Equals(c))
        {
            return context.SwitchLeftBraceState();
        }
        else
        {
            return context.SwitchEscapeState();
        }
    }
}

 /// <summary>
/// LeftBraceState
/// </summary>
public class LeftBraceState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;

        if(context.Configurator.RightBrace.Equals(c))
        {
            return context.SwitchRightBracePreState();
        }
        else
        {
            context.PropertyStringIndex = context.CurrentIndex-1;
            context.PropertyValueBuilder.Append(c);
            return context.SwitchReadPropertyKeyState();
        }
    }
}

 /// <summary>
/// ReadPropertyKeyState
/// </summary>
public class ReadPropertyKeyState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        int nextvalue = context.Reader.Peek(); 
        if (context.Configurator.StringEndFlag.Equals(i) || context.Configurator.StringEndFlag.Equals(nextvalue))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;           
        var nextChar = (char)nextvalue;
        if (context.Configurator.RightBrace.Equals(c) && context.Configurator.RightBrace.Equals(nextChar))
        {
            var propertyFiled = PropertyField.Build(context.PropertyStringIndex, context.CurrentIndex - 1, context.PropertyValueBuilder.ToString());
            context.PropertyValueBuilder.Clear();
            context.SwitchStartEscapeState();             
            return propertyFiled;
        }
        else
        {
            context.PropertyValueBuilder.Append(c);
            return context.ReadPropertyField();
        }
    }
}

 /// <summary>
/// RightBracePreState
/// </summary>
public class RightBracePreState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;
        if (context.Configurator.RightBrace.Equals(c))
        {
            return context.SwitchRightBraceState();
        }
        else
        {
            return context.ReadPropertyField();
        }
    }
}

 /// <summary>
/// RightBraceState
/// </summary>
public class RightBraceState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;
        if (context.Configurator.LeftBrace.Equals(c))
        {
            return context.SwitchLeftBracePreState();
        }
        else
        {
            return context.SwitchEscapeState();
        }
    }
}

 /// <summary>
/// StringEndState
/// </summary>
 public class StringEndState : IState
{
    public PropertyField Read(PropertyReader context)
    {
        int i = context.Reader.Read();
        if (context.Configurator.StringEndFlag.Equals(i))
        {
            return context.SwitchStringEndState();
        }
        char c = (char)i;
        context.CurrentIndex += 1;

        context.PropertyValueBuilder.Clear();
        return context.ReadPropertyField();
    }
}
```

* __Open for call__

```
public static class Template
{
    public static string Replace(string templateStr,Dictionary<string,object> data)
    {
        List<PropertyField> propertyFields = new List<PropertyField>();         

        using (var textReader = new StringReader(templateStr))
        {
            PropertyReader reader = new PropertyReader(textReader);
            PropertyField filed;

            while ((filed = reader.ReadPropertyField()) != null)
            {
                propertyFields.Add(PropertyField.Build(filed.PropertyCharStartIndex, filed.PropertyCharEndIndex, filed.PropertyKey));
            }
        }
        StringBuilder templateResult = new StringBuilder();
        int charLastIndex = 0;
        int propertyIndex = 0;
        foreach(var propertyField in propertyFields)
        {
            int startLeftIndex = propertyField.PropertyCharStartIndex - 2;
            int endRightIndex = propertyField.PropertyCharEndIndex + 2;

            templateResult.Append(templateStr.Substring(charLastIndex, startLeftIndex-charLastIndex));
            string key = propertyField.PropertyKey.Trim();
            if (data!=null &&data.ContainsKey(key))
            {
                templateResult.Append(data[key]);
            }
            charLastIndex = endRightIndex;
            propertyIndex += 1;
        }
        templateResult.Append(templateStr.Substring(charLastIndex, templateStr.Length - charLastIndex));
        return templateResult.ToString();
    }
}
```

### unit test

```
[TestFixture]
public class PropetyReaderTest
{
    [Test]
    public void ReaderProperties_Test()
    {
        string template = "Your name is {{ name }} ";
        PropertyField filed;
        using (var textReader = new StringReader(template))
        {
            PropertyReader reader = new PropertyReader(textReader);               
            while((filed =reader.ReadPropertyField())!=null)
            {
                int startIndex = filed.PropertyCharStartIndex;
                int endIndex = filed.PropertyCharEndIndex;
                string key = filed.PropertyKey;
            }
        }
        Assert.IsNotNull(filed);
    }
        
    [Test]
    public void Sample01_Test()
    {
        string template = "Your name is {{ name }} ";
        var data = new Dictionary<string, object>()
        {
            {"name","Bill" }
        };
        string result = Template.Replace(template, data);

        Assert.AreEqual("Your name is Bill ", result);
    }

    [Test]
    public void Sample02_Test()
    {
        string template = "Your name is {{ name }} and I am forever {{ age }}.";
        var data = new Dictionary<string, object>()
        {
            {"name","Bill" },
            {"age",21 }
        };
        string result = Template.Replace(template, data);

        Assert.AreEqual("Your name is Bill and I am forever 21.", result);
    }
}
```