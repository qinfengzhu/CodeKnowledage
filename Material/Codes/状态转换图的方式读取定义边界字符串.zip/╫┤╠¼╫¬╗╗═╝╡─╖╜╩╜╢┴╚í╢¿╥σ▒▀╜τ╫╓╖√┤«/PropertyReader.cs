﻿using SOLib.States;
using System;
using System.IO;
using System.Text;

namespace SOLib
{
    /// <summary>
    /// Property Reader Context
    /// </summary>
    public class PropertyReader
    {
        public TextReader Reader { get; private set; }
        public int PropertyStringIndex { get; set; } = 0;
        public int CurrentIndex { get; set; } = 0;
        public StringBuilder PropertyValueBuilder { get; } = new StringBuilder();
        public Configurator Configurator { get; } = new Configurator();
        public IState State { get; set; } = StateManager.EscapeState;
        public PropertyReader(TextReader reader)
        {
            Reader = reader;
        }

        public PropertyField ReadPropertyField()
        {
            if (State is StringEndState)
            {
                return null;
            }
            return State.Read(this);
        }
    }
}
