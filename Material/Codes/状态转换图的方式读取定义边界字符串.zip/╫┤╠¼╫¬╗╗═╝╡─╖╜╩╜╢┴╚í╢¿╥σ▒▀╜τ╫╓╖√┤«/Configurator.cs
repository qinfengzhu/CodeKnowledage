﻿using System;

namespace SOLib
{
    public class Configurator
    {
        public virtual char LeftBrace => '{';
        public virtual char RightBrace => '}';
        public int StringEndFlag => -1;
    }
}
