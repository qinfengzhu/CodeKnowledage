﻿using System;

namespace SOLib
{
    public interface IState
    {
        PropertyField Read(PropertyReader context);
    }
}
