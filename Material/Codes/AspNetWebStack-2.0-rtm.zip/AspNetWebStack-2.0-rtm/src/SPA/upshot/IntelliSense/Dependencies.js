﻿/// <reference path="jquery-1.5.2-vsdoc.js" />
/// <reference path="knockout-2.0.0.debug.js" />
// top-level objects - these could possibly be transitioned to script dependencies
var upshot = {}, WinJS = {};
WinJS.Namespace = {};
