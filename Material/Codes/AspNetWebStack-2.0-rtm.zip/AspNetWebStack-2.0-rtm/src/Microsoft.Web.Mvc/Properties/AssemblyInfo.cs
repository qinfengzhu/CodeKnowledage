﻿// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Web.Mvc.dll")]
[assembly: AssemblyDescription("Microsoft.Web.Mvc.dll")]
[assembly: Guid("f3507a98-9429-404b-9e0e-1b426a5b3ad5")]
[assembly: InternalsVisibleTo("Microsoft.Web.Mvc.Test")]
