﻿namespace Microsoft.Web.Mvc.ModelBinding {
    using System;

    public enum BindingBehavior {
        Optional = 0,
        Never,
        Required
    }
}
