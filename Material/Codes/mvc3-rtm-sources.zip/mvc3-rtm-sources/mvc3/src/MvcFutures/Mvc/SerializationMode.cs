﻿namespace Microsoft.Web.Mvc {
    using System;
    using System.Diagnostics.CodeAnalysis;

    public enum SerializationMode {

        Signed = 0,
        EncryptedAndSigned = 1

    }
}
