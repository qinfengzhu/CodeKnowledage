﻿using System;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.Web.Mvc.dll")]
[assembly: AssemblyDescription("Microsoft.Web.Mvc.dll")]
[assembly: ComVisible(false)]
[assembly: Guid("f3507a98-9429-404b-9e0e-1b426a5b3ad5")]
[assembly: CLSCompliant(true)]
[assembly: InternalsVisibleTo("Microsoft.Web.Mvc.Test")]
