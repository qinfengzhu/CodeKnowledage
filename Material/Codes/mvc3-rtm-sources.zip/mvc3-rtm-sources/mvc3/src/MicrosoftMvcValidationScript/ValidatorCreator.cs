﻿namespace Sys.Mvc {
    using System;

    public delegate Validator ValidatorCreator(JsonValidationRule rule);

}
