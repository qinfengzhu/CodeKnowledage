﻿namespace System.Web.Mvc {
    using System;

    internal delegate IUnvalidatedRequestValues UnvalidatedRequestValuesAccessor(ControllerContext controllerContext);

}
