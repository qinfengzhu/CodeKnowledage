﻿namespace System.Web.Mvc {
    internal interface IMvcControlBuilder {
        string Inherits { set; }
    }
}
