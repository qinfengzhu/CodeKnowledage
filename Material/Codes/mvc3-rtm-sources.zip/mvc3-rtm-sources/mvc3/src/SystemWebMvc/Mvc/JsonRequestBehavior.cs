﻿namespace System.Web.Mvc {
    public enum JsonRequestBehavior {
        AllowGet,
        DenyGet,
    }
}
