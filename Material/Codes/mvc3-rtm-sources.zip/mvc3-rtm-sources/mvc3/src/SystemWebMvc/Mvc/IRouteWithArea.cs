﻿namespace System.Web.Mvc {
    using System;

    public interface IRouteWithArea {

        string Area { get; }

    }
}
