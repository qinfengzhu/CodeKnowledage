﻿namespace System.Web.Mvc {

    public delegate bool ActionSelector(ControllerContext controllerContext);

}
