﻿namespace System.Web.Mvc.Async {
    using System;

    // Dummy type used for passing something resembling 'void' to the async delegate functions
    internal struct AsyncVoid {
    }
}
