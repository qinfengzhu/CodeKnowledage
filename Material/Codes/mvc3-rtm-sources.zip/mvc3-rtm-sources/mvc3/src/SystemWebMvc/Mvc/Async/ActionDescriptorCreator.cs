﻿namespace System.Web.Mvc.Async {
    using System;

    internal delegate ActionDescriptor ActionDescriptorCreator(string actionName, ControllerDescriptor controllerDescriptor);

}
