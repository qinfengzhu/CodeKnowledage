﻿namespace System.Web.Mvc {
    internal interface IUniquelyIdentifiable {
        string UniqueId { get; }
    }
}