﻿namespace System.Web.Mvc.Async {
    using System;

    internal delegate void EndInvokeDelegate(IAsyncResult asyncResult);
}
